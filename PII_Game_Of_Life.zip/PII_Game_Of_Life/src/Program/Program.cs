﻿using System;
using System.IO;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading;

namespace Ucu.Poo.GameOfLife
{
    class CreadorDesdeArchivo
    {
        public static Tablero CrearTablero()
        {
            string url = @"../../../PII_Game_Of_Life/assets/board.txt";
            string content = File.ReadAllText(url);
            string[] contentLines = content.Split('\n');

            Tablero board = new Tablero(contentLines.Length, contentLines[0].Length);

            for (int y = 0; y < contentLines.Length; y++)
            {
                for (int x = 0; x < contentLines[y].Length; x++)
                {
                    if (contentLines[y][x] == '1')
                    {
                        board.Células[x, y] = true;
                    }
                }
            }
            return board;
        }
    }

    class ImpresoraConsola
    {
        public static void Imprimir(Tablero board)
        {
            Console.Clear();
            StringBuilder s = new StringBuilder();
            for (int y = 0; y < board.Alto; y++)
            {
                for (int x = 0; x < board.Ancho; x++)
                {
                    if (board.Células[x, y])
                    {
                        s.Append("|X|");
                    }
                    else
                    {
                        s.Append("___");
                    }
                }
                s.Append("\n");
            }
            Console.WriteLine(s.ToString());
            Thread.Sleep(300);
        }
    }

    class Tablero
    {
        public bool[,] Células { get; set; }
        public int Ancho
        {
            get
            {
                return this.Células.GetLength(0);
            }
        }
        public int Alto
        {
            get
            {
                return this.Células.GetLength(1);
            }
        }
        public Tablero(int ancho, int alto)
        {
            this.Células = new bool[ancho, alto];
        }

        public void LogicaJuego()
        {
            bool[,] cloneboard = new bool[this.Ancho, this.Alto];
            for (int x = 0; x < this.Ancho; x++)
            {
                for (int y = 0; y < this.Alto; y++)
                {
                    int aliveNeighbors = 0;
                    for (int i = x - 1; i <= x + 1; i++)
                    {
                        for (int j = y - 1; j <= y + 1; j++)
                        {
                            if (i >= 0 && i < this.Ancho && j >= 0 && j < this.Alto && this.Células[i, j])
                            {
                                aliveNeighbors++;
                            }
                        }
                    }
                    if (this.Células[x, y])
                    {
                        aliveNeighbors--;
                    }
                    if (this.Células[x, y] && aliveNeighbors < 2)
                    {
                        //Celula muere por baja población
                        cloneboard[x, y] = false;
                    }
                    else if (this.Células[x, y] && aliveNeighbors > 3)
                    {
                        //Celula muere por sobrepoblación
                        cloneboard[x, y] = false;
                    }
                    else if (!this.Células[x, y] && aliveNeighbors == 3)
                    {
                        //Celula nace por reproducción
                        cloneboard[x, y] = true;
                    }
                    else
                    {
                        //Celula mantiene el estado que tenía
                        cloneboard[x, y] = this.Células[x, y];
                    }
                }
            }
            this.Células = cloneboard;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            Tablero gameBoard = CreadorDesdeArchivo.CrearTablero();
            while (true)
            {
                gameBoard.LogicaJuego();
                ImpresoraConsola.Imprimir(gameBoard);
            }
        }
    }
}